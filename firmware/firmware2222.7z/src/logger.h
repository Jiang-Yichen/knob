
class Logger {
    public:
        Logger() {};
        virtual ~Logger() {};
    
};
