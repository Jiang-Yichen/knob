Readme for Processing examples 
==============================

Examples in this directory are for the processing ide
goto processing.org for the tooling

These examples are able to receive the Serial outputs from the ARDUINO sketches, parse them and visualize them graphically. 

Each of these processing sketches contains a comment referring to an according Arduino sketch which has to run on a connected MC. 

When the processing application is running, you have to choose a COM Port, which you would normally use for the Serial monitor. 
Please do not use the same COM Port in multiple programs. This may cause errors and unexpected behaviours. 

